# Backend Flask Application

This directory contains the Flask backend for the Azure Flask React App project. The backend serves as an API that provides data to the React frontend.

## Setup Instructions

1. **Clone the Repository**
   ```bash
   git clone <repository-url>
   cd azure-flask-react-app/backend
   ```

2. **Create a Virtual Environment**
   It is recommended to create a virtual environment to manage dependencies.
   ```bash
   python -m venv venv
   source venv/bin/activate  # On Windows use `venv\Scripts\activate`
   ```

3. **Install Dependencies**
   Install the required Python packages using pip.
   ```bash
   pip install -r requirements.txt
   ```

4. **Run the Flask Application**
   Start the Flask server.
   ```bash
   python App.py
   ```
   The application will be running at `http://localhost:5000`.

## API Endpoints

- **GET /api/growth**
  - Returns hardcoded growth data for databases across multiple servers.

- **GET /api/top-tables?database={database_name}**
  - Returns dummy data for the top tables in the specified database.

## Additional Information

Make sure to configure CORS if you are accessing the API from a different origin, especially when deploying the application.